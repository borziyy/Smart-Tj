export const AUTHOR = 'AKHUNOV BOZORBOY';
export const AUTHOR_INITIALS = 'AB';
export const APP_VERSION = '1.0.0';

export const C = {
  bg: '#07122B',
  bg2: '#0B1D45',
  card: '#10244F',
  card2: '#16306A',
  cardHi: '#1C3B80',
  border: 'rgba(148, 180, 255, 0.14)',
  borderHi: 'rgba(120, 190, 255, 0.45)',
  accent: '#3B82F6',
  accentDark: '#1D4ED8',
  cyan: '#38D5F5',
  text: '#F3F7FF',
  textDim: '#B4C3E3',
  muted: '#7F91B8',
  success: '#22C55E',
  successBg: 'rgba(34, 197, 94, 0.16)',
  danger: '#F05252',
  dangerBg: 'rgba(240, 82, 82, 0.16)',
  gold: '#FBBF24',
};

export const GRAD = {
  screen: ['#07122B', '#0A1A40', '#0B2257'],
  primary: ['#3B82F6', '#2563EB'],
  hero: ['#2563EB', '#1E40AF'],
  cyan: ['#38D5F5', '#3B82F6'],
};

export const SUBJECTS = {
  math: { color: '#3B82F6', grad: ['#3B82F6', '#1D4ED8'], icon: 'calculator-variant-outline' },
  physics: { color: '#A855F7', grad: ['#A855F7', '#7C3AED'], icon: 'atom' },
  chemistry: { color: '#10B981', grad: ['#10B981', '#047857'], icon: 'flask-outline' },
  biology: { color: '#F59E0B', grad: ['#F59E0B', '#D97706'], icon: 'dna' },
};

export const SUBJECT_KEYS = ['math', 'physics', 'chemistry', 'biology'];

export const R = { sm: 10, md: 16, lg: 22, xl: 28 };
