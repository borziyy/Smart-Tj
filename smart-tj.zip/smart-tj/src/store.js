import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { makeT } from './i18n';

const KEY = 'smarttj.state.v1';

const emptySubject = () => ({ answered: 0, correct: 0, learned: [] });

const initialState = {
  lang: 'tj',
  testsTaken: 0,
  answered: 0,
  correct: 0,
  best: 0,
  subjects: {
    math: emptySubject(),
    physics: emptySubject(),
    chemistry: emptySubject(),
    biology: emptySubject(),
  },
  mistakes: [],
  history: [],
  streak: 0,
  lastDay: null,
};

function dayKey(d = new Date()) {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function daysBetween(a, b) {
  const pa = a.split('-').map(Number);
  const pb = b.split('-').map(Number);
  const da = new Date(pa[0], pa[1] - 1, pa[2]);
  const db = new Date(pb[0], pb[1] - 1, pb[2]);
  return Math.round((db - da) / 86400000);
}

const Ctx = createContext(null);

export function AppProvider({ children }) {
  const [state, setState] = useState(initialState);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(KEY);
        if (raw) {
          const saved = JSON.parse(raw);
          setState((s) => ({
            ...s,
            ...saved,
            subjects: { ...s.subjects, ...(saved.subjects || {}) },
          }));
        }
      } catch (e) {
        // ignore broken storage
      }
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    if (!ready) return;
    AsyncStorage.setItem(KEY, JSON.stringify(state)).catch(() => {});
  }, [state, ready]);

  const setLang = useCallback((lang) => setState((s) => ({ ...s, lang })), []);

  // answers: [{ id, subject, correct: bool }]
  const recordTest = useCallback((summary) => {
    let isRecord = false;
    setState((s) => {
      const subjects = { ...s.subjects };
      const mistakes = new Set(s.mistakes);
      let correct = 0;
      for (const a of summary.answers) {
        const sub = { ...(subjects[a.subject] || emptySubject()) };
        sub.answered += 1;
        if (a.correct) {
          sub.correct += 1;
          correct += 1;
          if (!sub.learned.includes(a.id)) sub.learned = [...sub.learned, a.id];
          mistakes.delete(a.id);
        } else {
          mistakes.add(a.id);
        }
        subjects[a.subject] = sub;
      }
      const total = summary.total || summary.answers.length || 1;
      const percent = Math.round((correct / total) * 100);
      isRecord = percent > s.best && total >= 5;

      const today = dayKey();
      let streak = s.streak;
      if (s.lastDay !== today) {
        const gap = s.lastDay ? daysBetween(s.lastDay, today) : null;
        streak = gap === 1 ? s.streak + 1 : 1;
      }

      const entry = {
        date: Date.now(),
        title: summary.title,
        subject: summary.subject,
        correct,
        total,
        percent,
        seconds: summary.seconds,
      };

      return {
        ...s,
        testsTaken: s.testsTaken + 1,
        answered: s.answered + summary.answers.length,
        correct: s.correct + correct,
        best: total >= 5 ? Math.max(s.best, percent) : s.best,
        subjects,
        mistakes: Array.from(mistakes),
        history: [entry, ...s.history].slice(0, 30),
        streak,
        lastDay: today,
      };
    });
    return isRecord;
  }, []);

  const resetStats = useCallback(() => {
    setState((s) => ({ ...initialState, lang: s.lang }));
  }, []);

  const value = useMemo(
    () => ({ state, ready, t: makeT(state.lang), lang: state.lang, setLang, recordTest, resetStats }),
    [state, ready, setLang, recordTest, resetStats]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  return useContext(Ctx);
}
