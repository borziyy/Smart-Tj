import { AI_PROXY_URL, AI_TIMEOUT_MS } from './config';
import { DB } from './data';
import { MATERIALS } from './data/materials';
import { fmt } from './data/generators';

// ---------------- ОНЛАЙН ----------------
async function askOnline(question, lang, history) {
  if (!AI_PROXY_URL) throw new Error('no-proxy');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), AI_TIMEOUT_MS);
  try {
    const res = await fetch(AI_PROXY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, lang, history: history.slice(-6) }),
      signal: ctrl.signal,
    });
    if (!res.ok) throw new Error('http-' + res.status);
    const data = await res.json();
    if (!data.answer) throw new Error('empty');
    return data.answer;
  } finally {
    clearTimeout(timer);
  }
}

// ---------------- ОФЛАЙН: математика ----------------
function norm(s) {
  return s
    .toLowerCase()
    .replace(/[−–—]/g, '-')
    .replace(/[×·]/g, '*')
    .replace(/[÷:]/g, '/')
    .replace(/х/g, 'x') // русская «х»
    .replace(/x²/g, 'x^2')
    .replace(/(\d),(\d)/g, '$1.$2')
    .replace(/\s+/g, '');
}

// многочлен степени ≤ 2: возвращает [c0, c1, c2] или null
function parsePoly(side) {
  if (!side || /[^0-9x^.+\-]/.test(side)) return null;
  const terms = side.replace(/-/g, '+-').split('+').filter((t) => t !== '');
  const c = [0, 0, 0];
  for (const term of terms) {
    const m = term.match(/^(-?)(\d*\.?\d*)(x(\^2)?)?$/);
    if (!m) return null;
    const sign = m[1] ? -1 : 1;
    const hasX = !!m[3];
    const deg = m[4] ? 2 : hasX ? 1 : 0;
    if (!m[2] && !hasX) return null;
    const num = m[2] ? parseFloat(m[2]) : 1;
    if (Number.isNaN(num)) return null;
    c[deg] += sign * num;
  }
  return c;
}

function solveEquation(raw, lang) {
  const tj = lang === 'tj';
  const s = norm(raw).replace(/^(реши|решите|решить|ҳалкунед|ҳалкун|ёбед|найди|найдите)/, '');
  const eqMatch = s.match(/([0-9x^.+\-]+)=([0-9x^.+\-]+)/);
  if (!eqMatch || !eqMatch[0].includes('x')) return null;
  const L = parsePoly(eqMatch[1]);
  const Rr = parsePoly(eqMatch[2]);
  if (!L || !Rr) return null;
  const a = L[2] - Rr[2];
  const b = L[1] - Rr[1];
  const c = L[0] - Rr[0];
  const head = tj ? 'Ҳал' : 'Решение';
  if (a === 0) {
    if (b === 0) return null;
    const x = -c / b;
    return (
      `${head}:\n` +
      `1) ${tj ? 'Ҳадҳоро бо x ба тарафи чап, ададҳоро ба рост мегузаронем' : 'Переносим слагаемые с x влево, числа вправо'}: ${fmt(b)}x = ${fmt(-c)}\n` +
      `2) ${tj ? 'Ҳар ду тарафро ба' : 'Делим обе части на'} ${fmt(b)}: x = ${fmt(-c)} / ${fmt(b)}\n\n` +
      `✅ x = ${fmt(x)}`
    );
  }
  const D = b * b - 4 * a * c;
  let out =
    `${head}:\n` +
    `${tj ? 'Муодилаи квадратӣ' : 'Квадратное уравнение'}: a = ${fmt(a)}, b = ${fmt(b)}, c = ${fmt(c)}\n` +
    `D = b² − 4ac = ${fmt(b * b)} − ${fmt(4 * a * c)} = ${fmt(D)}\n`;
  if (D < 0) return out + `\n❌ D < 0 — ${tj ? 'решаҳои ҳақиқӣ нест' : 'действительных корней нет'}.`;
  if (D === 0) return out + `\n✅ x = −b / 2a = ${fmt(-b / (2 * a))}`;
  const x1 = (-b + Math.sqrt(D)) / (2 * a);
  const x2 = (-b - Math.sqrt(D)) / (2 * a);
  return out + `x = (−b ± √D) / 2a\n\n✅ x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}`;
}

// безопасный калькулятор: + − * / ^ ( ) и √
function calc(raw, lang) {
  let s = norm(raw).replace(/[=?]+$/, '').replace(/^(сколькобудет|вычисли|вычислите|ҳисобкунед|чандмешавад)/, '');
  s = s.replace(/√(\d+(\.\d+)?)/g, 'sqrt($1)').replace(/√\(/g, 'sqrt(');
  if (!/\d/.test(s) || /[^0-9+\-*/^().sqrt]/.test(s) || !/[+\-*/^]|sqrt/.test(s)) return null;
  let i = 0;
  const peek = () => s[i];
  function num() {
    if (s.startsWith('sqrt(', i)) {
      i += 5;
      const v = expr();
      if (s[i++] !== ')') throw new Error('paren');
      return Math.sqrt(v);
    }
    if (peek() === '(') {
      i++;
      const v = expr();
      if (s[i++] !== ')') throw new Error('paren');
      return v;
    }
    if (peek() === '-') {
      i++;
      return -num();
    }
    const m = s.slice(i).match(/^\d+(\.\d+)?/);
    if (!m) throw new Error('num');
    i += m[0].length;
    return parseFloat(m[0]);
  }
  function pow() {
    let v = num();
    while (peek() === '^') {
      i++;
      v = Math.pow(v, num());
    }
    return v;
  }
  function term() {
    let v = pow();
    while (peek() === '*' || peek() === '/') {
      const op = s[i++];
      const r = pow();
      v = op === '*' ? v * r : v / r;
    }
    return v;
  }
  function expr() {
    let v = term();
    while (peek() === '+' || peek() === '-') {
      const op = s[i++];
      const r = term();
      v = op === '+' ? v + r : v - r;
    }
    return v;
  }
  try {
    const v = expr();
    if (i !== s.length || !Number.isFinite(v)) return null;
    const shown = raw.replace(/[=?]+\s*$/, '').replace(/^[^\d√(−-]*/, '').trim();
    return `${lang === 'tj' ? 'Ҷавоб' : 'Ответ'}: ${shown} = ${fmt(v)}`;
  } catch (e) {
    return null;
  }
}

// ---------------- ОФЛАЙН: поиск по базе ----------------
const STOP = new Set(
  (
    'что такое как это для при чем чём кто где когда почему зачем какой какая какие каков скажи объясни расскажи ' +
    'пожалуйста можно мне про или и в на с по из к у о от до the is what чӣ чист кадом аст дар ба ва бо аз ки чанд ' +
    'кист мебошад кунед барои гӯед шарҳ диҳед лутфан ин он ман чиро чаро кай куҷо'
  ).split(' ')
);

function tokens(text) {
  return text
    .toLowerCase()
    .replace(/[^a-zа-яёӣқҳҷӯғ0-9²³₀-₉ ]/gi, ' ')
    .split(/\s+/)
    .filter((w) => w.length >= 2 && !STOP.has(w))
    .map((w) => (w.length > 5 ? w.slice(0, w.length > 7 ? 6 : 5) : w));
}

let INDEX = null;
function buildIndex() {
  const docs = [];
  for (const q of DB.all) {
    for (const lang of ['ru', 'tj']) {
      const L = q[lang];
      docs.push({ kind: 'q', lang, q, text: `${L.q} ${L.o[0]} ${L.e}`, title: L.q });
    }
  }
  for (const subject of Object.keys(MATERIALS)) {
    for (const topic of MATERIALS[subject]) {
      for (const lang of ['ru', 'tj']) {
        const T = topic[lang];
        for (const [k, v] of T.items) {
          docs.push({ kind: 'm', lang, topic: T.title, k, v, text: `${T.title} ${k} ${v}` });
        }
      }
    }
  }
  for (const d of docs) d.tok = new Set(tokens(d.text));
  const df = {};
  for (const d of docs) for (const w of d.tok) df[w] = (df[w] || 0) + 1;
  INDEX = { docs, df, N: docs.length };
}

function search(question, lang) {
  if (!INDEX) buildIndex();
  const qt = Array.from(new Set(tokens(question)));
  if (!qt.length) return null;
  let best = null;
  for (const d of INDEX.docs) {
    let score = 0;
    let hits = 0;
    for (const w of qt) {
      if (d.tok.has(w)) {
        hits++;
        score += Math.log(INDEX.N / INDEX.df[w]);
      }
    }
    if (!hits) continue;
    if (d.lang === lang) score *= 1.15;
    if (d.kind === 'q' && /^(что|чӣ|chi)/i.test(question.trim())) score *= 1.05;
    if (!best || score > best.score) best = { ...d, score, hits };
  }
  if (!best) return null;
  const needHits = qt.length >= 3 ? 2 : 1;
  if (best.hits < needHits || best.score < 2.5) return null;
  return best;
}

function answerFromBase(question, lang) {
  const best = search(question, lang);
  if (!best) return null;
  const tj = lang === 'tj';
  if (best.kind === 'm') {
    return `📘 ${best.topic}\n\n${best.k}\n${best.v}`;
  }
  const L = best.q[lang];
  return (
    `📚 ${tj ? 'Саволи монанд' : 'Похожий вопрос'}: ${L.q}\n\n` +
    `✅ ${tj ? 'Ҷавоб' : 'Ответ'}: ${L.o[0]}\n\n` +
    `💡 ${L.e}`
  );
}

export function answerOffline(question, lang) {
  return solveEquation(question, lang) || calc(question, lang) || answerFromBase(question, lang);
}

export const hasOnline = () => !!AI_PROXY_URL;

// Главная функция: сначала онлайн, при ошибке — офлайн
export async function ask(question, lang, history = []) {
  if (AI_PROXY_URL) {
    try {
      const text = await askOnline(question, lang, history);
      return { text, source: 'online' };
    } catch (e) {
      // нет интернета или сервер недоступен — отвечаем офлайн
    }
  }
  const text = answerOffline(question, lang);
  return { text, source: 'offline' };
}
