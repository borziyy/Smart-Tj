import React, { useRef } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { C, GRAD, R, SUBJECTS } from './theme';
import { useApp } from './store';

export function haptic(kind = 'light') {
  try {
    if (kind === 'success') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    else if (kind === 'error') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    else Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  } catch (e) {
    // web / unsupported
  }
}

export function Screen({ children, edges = ['top'], style }) {
  return (
    <LinearGradient colors={GRAD.screen} style={{ flex: 1 }}>
      <View pointerEvents="none" style={styles.glow} />
      <SafeAreaView edges={edges} style={[{ flex: 1 }, style]}>
        {children}
      </SafeAreaView>
    </LinearGradient>
  );
}

export function Logo({ size = 40 }) {
  return (
    <LinearGradient
      colors={['#4F8DFF', '#1D4ED8']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{
        width: size,
        height: size,
        borderRadius: size * 0.28,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: Math.max(1.5, size * 0.035),
        borderColor: 'rgba(160, 220, 255, 0.85)',
      }}
    >
      <Text style={{ color: '#fff', fontWeight: '900', fontSize: size * 0.56, marginTop: -size * 0.03 }}>S</Text>
    </LinearGradient>
  );
}

export function LangToggle() {
  const { lang, setLang } = useApp();
  return (
    <Pressable
      onPress={() => {
        haptic();
        setLang(lang === 'tj' ? 'ru' : 'tj');
      }}
      style={styles.langBtn}
      hitSlop={8}
    >
      <Text style={styles.langText}>{lang === 'tj' ? 'TJ' : 'RU'}</Text>
      <MaterialCommunityIcons name="swap-horizontal" size={14} color={C.cyan} />
    </Pressable>
  );
}

export function Header({ title, right }) {
  return (
    <View style={styles.header}>
      <Logo size={36} />
      <Text style={styles.headerTitle} numberOfLines={1}>{title}</Text>
      <View style={{ flex: 1 }} />
      {right ?? <LangToggle />}
    </View>
  );
}

export function Card({ children, style, hi }) {
  return <View style={[styles.card, hi && styles.cardHi, style]}>{children}</View>;
}

const APressable = Animated.createAnimatedComponent(Pressable);

export function Press({ children, onPress, style, disabled }) {
  const scale = useRef(new Animated.Value(1)).current;
  const to = (v) => Animated.spring(scale, { toValue: v, useNativeDriver: true, speed: 40, bounciness: 6 }).start();
  return (
    <APressable
      disabled={disabled}
      onPress={(e) => {
        haptic();
        onPress && onPress(e);
      }}
      onPressIn={() => to(0.97)}
      onPressOut={() => to(1)}
      style={[style, { transform: [{ scale }] }]}
    >
      {children}
    </APressable>
  );
}

export function PrimaryButton({ title, onPress, icon, colors = GRAD.primary, style, textColor = '#fff' }) {
  return (
    <Press onPress={onPress} style={style}>
      <LinearGradient colors={colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.primaryBtn}>
        {icon ? <MaterialCommunityIcons name={icon} size={20} color={textColor} /> : null}
        <Text style={[styles.primaryText, { color: textColor }]}>{title}</Text>
      </LinearGradient>
    </Press>
  );
}

export function GhostButton({ title, onPress, icon, style }) {
  return (
    <Press onPress={onPress} style={[styles.ghostBtn, style]}>
      {icon ? <MaterialCommunityIcons name={icon} size={20} color={C.text} /> : null}
      <Text style={styles.ghostText}>{title}</Text>
    </Press>
  );
}

export function ProgressBar({ value, color = C.accent, height = 6, track = 'rgba(255,255,255,0.08)' }) {
  const pct = Math.max(0, Math.min(1, value || 0));
  return (
    <View style={{ height, backgroundColor: track, borderRadius: height, overflow: 'hidden' }}>
      <View style={{ width: `${pct * 100}%`, height, backgroundColor: color, borderRadius: height }} />
    </View>
  );
}

export function SubjectIcon({ subject, size = 48 }) {
  const s = SUBJECTS[subject];
  return (
    <LinearGradient
      colors={s.grad}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={{ width: size, height: size, borderRadius: size * 0.3, alignItems: 'center', justifyContent: 'center' }}
    >
      <MaterialCommunityIcons name={s.icon} size={size * 0.52} color="#fff" />
    </LinearGradient>
  );
}

export function SectionTitle({ children, style }) {
  return <Text style={[styles.section, style]}>{children}</Text>;
}

export const styles = StyleSheet.create({
  glow: {
    position: 'absolute',
    top: -140,
    right: -120,
    width: 360,
    height: 360,
    borderRadius: 180,
    backgroundColor: 'rgba(59, 130, 246, 0.14)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 12,
    gap: 12,
  },
  headerTitle: { color: C.text, fontSize: 22, fontWeight: '800', letterSpacing: 0.2 },
  langBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(59,130,246,0.18)',
    borderWidth: 1,
    borderColor: C.borderHi,
  },
  langText: { color: C.text, fontWeight: '800', fontSize: 14 },
  card: {
    backgroundColor: C.card,
    borderRadius: R.lg,
    borderWidth: 1,
    borderColor: C.border,
    padding: 16,
  },
  cardHi: { backgroundColor: C.card2, borderColor: C.borderHi },
  primaryBtn: {
    height: 54,
    borderRadius: R.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 20,
  },
  primaryText: { fontSize: 17, fontWeight: '800' },
  ghostBtn: {
    height: 54,
    borderRadius: R.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: C.border,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  ghostText: { color: C.text, fontSize: 16, fontWeight: '700' },
  section: { color: C.text, fontSize: 19, fontWeight: '800', marginBottom: 12, marginTop: 8 },
});
