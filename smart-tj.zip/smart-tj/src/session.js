// Временная память между экраном теста и экраном результата
let lastResult = null;
export const setLastResult = (r) => {
  lastResult = r;
};
export const getLastResult = () => lastResult;
