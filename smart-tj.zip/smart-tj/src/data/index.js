import math from './math';
import physics from './physics';
import chemistry from './chemistry';
import biology from './biology';
import { GENERATED } from './generators';

const RAW = { math, physics, chemistry, biology };

function build() {
  const all = [];
  const bySubject = {};
  for (const subject of Object.keys(RAW)) {
    const seen = new Set();
    const list = [...RAW[subject], ...GENERATED[subject]].filter((q) => {
      if (seen.has(q[0])) return false;
      seen.add(q[0]);
      return true;
    });
    bySubject[subject] = list.map((q, i) => {
      const item = {
        id: `${subject}-${i}`,
        subject,
        ru: { q: q[0], o: q[1], e: q[2] },
        tj: { q: q[3], o: q[4], e: q[5] },
      };
      all.push(item);
      return item;
    });
  }
  const byId = {};
  for (const q of all) byId[q.id] = q;
  return { all, bySubject, byId };
}

export const DB = build();
export const TOTAL_QUESTIONS = DB.all.length;

export function shuffled(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Готовит вопрос к показу: перемешивает варианты, запоминает индекс правильного
export function prepare(q) {
  const order = shuffled([0, 1, 2, 3]);
  return { ...q, order, correctPos: order.indexOf(0) };
}
