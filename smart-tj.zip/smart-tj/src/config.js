// Адрес сервера AI-помощника (см. папку server/ и README).
// Пока пусто — помощник работает в офлайн-режиме по встроенной базе.
// Пример: 'https://smart-tj-ai.your-name.workers.dev'
export const AI_PROXY_URL = '';

// Сколько ждать ответ сервера, мс
export const AI_TIMEOUT_MS = 20000;

// Олимпиадный режим
export const OLYMPIAD_QUESTIONS = 30;
export const OLYMPIAD_SECONDS = 20 * 60;
