import React, { useEffect, useRef } from 'react';
import { Animated, Easing, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Redirect, router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, GhostButton, haptic, PrimaryButton, Screen, SectionTitle } from '../src/ui';
import { useApp } from '../src/store';
import { getLastResult } from '../src/session';
import { AUTHOR, C, R } from '../src/theme';

export default function Result() {
  const { t, lang } = useApp();
  const r = getLastResult();
  const pop = useRef(new Animated.Value(0)).current;
  const count = useRef(new Animated.Value(0)).current;
  const [shown, setShown] = React.useState(0);

  useEffect(() => {
    if (!r) return;
    haptic(r.percent >= 50 ? 'success' : 'error');
    Animated.spring(pop, { toValue: 1, useNativeDriver: true, friction: 5 }).start();
    const id = count.addListener(({ value }) => setShown(Math.round(value)));
    Animated.timing(count, { toValue: r.percent, duration: 1100, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start();
    return () => count.removeListener(id);
  }, []);

  if (!r) return <Redirect href="/(tabs)" />;

  const grade =
    r.percent >= 85
      ? { msg: t('excellent'), icon: 'trophy', colors: ['#F59E0B', '#EA580C'] }
      : r.percent >= 50
      ? { msg: t('good'), icon: 'star-circle', colors: ['#3B82F6', '#1D4ED8'] }
      : { msg: t('tryMore'), icon: 'arm-flex', colors: ['#8B5CF6', '#6D28D9'] };

  const m = Math.floor(r.seconds / 60);
  const sec = r.seconds % 60;

  const retry = () => {
    const params = { mode: r.mode };
    if (r.mode === 'subject') {
      params.subject = r.subject;
      params.count = String(r.total);
    }
    router.replace({ pathname: '/quiz', params });
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <Text style={s.head}>{t('result')}</Text>
        <Text style={s.sub}>{r.title}</Text>
        {r.timeUp && <Text style={s.timeUp}>⏰ {t('timeUp')}</Text>}

        <Animated.View style={{ transform: [{ scale: pop.interpolate({ inputRange: [0, 1], outputRange: [0.6, 1] }) }], opacity: pop }}>
          <LinearGradient colors={grade.colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
            <View style={s.ring}>
              <MaterialCommunityIcons name={grade.icon} size={34} color="#fff" />
              <Text style={s.pct}>{shown}%</Text>
            </View>
            {r.isRecord && (
              <View style={s.record}>
                <MaterialCommunityIcons name="crown" size={16} color="#7C2D12" />
                <Text style={s.recordText}>{t('newRecord')}</Text>
              </View>
            )}
            <Text style={s.msg}>{grade.msg}</Text>
            <Text style={s.author}>{AUTHOR}</Text>
          </LinearGradient>
        </Animated.View>

        <View style={s.stats}>
          <Card style={s.stat}>
            <MaterialCommunityIcons name="check-circle" size={24} color={C.success} />
            <Text style={s.statNum}>{r.correct}</Text>
            <Text style={s.statLbl}>{t('rightAnswers')}</Text>
          </Card>
          <Card style={s.stat}>
            <MaterialCommunityIcons name="close-circle" size={24} color={C.danger} />
            <Text style={s.statNum}>{r.total - r.correct}</Text>
            <Text style={s.statLbl}>{t('wrongAnswers')}</Text>
          </Card>
          <Card style={s.stat}>
            <MaterialCommunityIcons name="clock-outline" size={24} color={C.cyan} />
            <Text style={s.statNum}>
              {m}:{sec < 10 ? '0' : ''}{sec}
            </Text>
            <Text style={s.statLbl}>{t('time')}</Text>
          </Card>
        </View>

        <View style={{ gap: 10, marginTop: 6 }}>
          <PrimaryButton title={t('retry')} icon="refresh" onPress={retry} />
          <GhostButton title={t('home')} icon="home-variant-outline" onPress={() => router.replace('/(tabs)')} />
        </View>

        <SectionTitle style={{ marginTop: 26 }}>{t('review')}</SectionTitle>
        {r.answers.map((a, i) => {
          const L = a.q[lang];
          const pickedText = a.picked === null || a.picked === undefined ? t('noAnswer') : L.o[a.q.order[a.picked]];
          return (
            <Card key={i} style={[s.review, { borderColor: a.correct ? 'rgba(34,197,94,0.4)' : 'rgba(240,82,82,0.4)' }]}>
              <View style={{ flexDirection: 'row', gap: 10 }}>
                <MaterialCommunityIcons name={a.correct ? 'check-circle' : 'close-circle'} size={22} color={a.correct ? C.success : C.danger} />
                <Text style={s.rq}>
                  {i + 1}. {L.q}
                </Text>
              </View>
              {!a.correct && (
                <Text style={s.rWrong}>
                  {t('yourAnswer')}: {pickedText}
                </Text>
              )}
              <Text style={s.rRight}>
                {t('correctAnswer')}: {L.o[0]}
              </Text>
              <Text style={s.rExp}>{L.e}</Text>
            </Card>
          );
        })}
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  head: { color: C.text, fontSize: 30, fontWeight: '900', textAlign: 'center', marginTop: 8 },
  sub: { color: C.textDim, fontSize: 15, fontWeight: '600', textAlign: 'center', marginTop: 4, marginBottom: 16 },
  timeUp: { color: C.danger, fontSize: 15, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
  hero: { borderRadius: R.xl, padding: 24, alignItems: 'center' },
  ring: {
    width: 150, height: 150, borderRadius: 75, borderWidth: 8, borderColor: 'rgba(255,255,255,0.35)',
    alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.12)',
  },
  pct: { color: '#fff', fontSize: 40, fontWeight: '900', fontVariant: ['tabular-nums'] },
  record: {
    flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FDE68A', borderRadius: 20,
    paddingHorizontal: 12, paddingVertical: 5, marginTop: 14,
  },
  recordText: { color: '#7C2D12', fontWeight: '900', fontSize: 13 },
  msg: { color: '#fff', fontSize: 19, fontWeight: '800', marginTop: 14, textAlign: 'center' },
  author: { color: 'rgba(255,255,255,0.75)', fontSize: 12, fontWeight: '800', letterSpacing: 1.5, marginTop: 8 },
  stats: { flexDirection: 'row', gap: 10, marginVertical: 16 },
  stat: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: 14, paddingHorizontal: 6 },
  statNum: { color: C.text, fontSize: 22, fontWeight: '900' },
  statLbl: { color: C.muted, fontSize: 12, fontWeight: '700' },
  review: { marginBottom: 10, gap: 6 },
  rq: { color: C.text, fontSize: 15, fontWeight: '700', flex: 1, lineHeight: 21 },
  rWrong: { color: C.danger, fontSize: 14, fontWeight: '600', marginLeft: 32 },
  rRight: { color: C.success, fontSize: 14, fontWeight: '700', marginLeft: 32 },
  rExp: { color: C.muted, fontSize: 13, lineHeight: 19, marginLeft: 32 },
});
