import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Header, Press, ProgressBar, Screen, SubjectIcon } from '../../src/ui';
import { useApp } from '../../src/store';
import { DB, TOTAL_QUESTIONS } from '../../src/data';
import { C, SUBJECTS, SUBJECT_KEYS } from '../../src/theme';

export default function Tests() {
  const { t, state } = useApp();
  return (
    <Screen>
      <Header title={t('tabTests')} />
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <Text style={s.h1}>{t('tabTests')}</Text>
        <Text style={s.sub}>
          {t('chooseSubject')} · {TOTAL_QUESTIONS} {t('questionsTotal')}
        </Text>

        {SUBJECT_KEYS.map((k) => {
          const total = DB.bySubject[k].length;
          const st = state.subjects[k];
          const acc = st.answered ? Math.round((st.correct / st.answered) * 100) : 0;
          return (
            <Press key={k} style={{ marginBottom: 12 }} onPress={() => router.push({ pathname: '/subject', params: { subject: k } })}>
              <Card style={s.row}>
                <SubjectIcon subject={k} size={56} />
                <View style={{ flex: 1, gap: 6 }}>
                  <Text style={s.title}>{t(k)}</Text>
                  <Text style={s.meta}>
                    {total} {t('questions')} · {t('accuracy')} {acc}%
                  </Text>
                  <ProgressBar value={st.learned.length / total} color={SUBJECTS[k].color} />
                </View>
                <MaterialCommunityIcons name="chevron-right" size={28} color={C.cyan} />
              </Card>
            </Press>
          );
        })}

        <Press style={{ marginTop: 6 }} onPress={() => router.push({ pathname: '/quiz', params: { mode: 'olympiad' } })}>
          <Card hi style={s.row}>
            <View style={[s.iconBox, { backgroundColor: 'rgba(251,191,36,0.18)' }]}>
              <MaterialCommunityIcons name="medal-outline" size={30} color={C.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.title}>{t('olympiad')}</Text>
              <Text style={s.meta}>{t('olympiadDesc')}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={28} color={C.gold} />
          </Card>
        </Press>
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  scroll: { paddingHorizontal: 20, paddingBottom: 30 },
  h1: { color: C.text, fontSize: 30, fontWeight: '900', marginTop: 4 },
  sub: { color: C.textDim, fontSize: 14, marginTop: 4, marginBottom: 18, fontWeight: '600' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  title: { color: C.text, fontSize: 18, fontWeight: '800' },
  meta: { color: C.muted, fontSize: 13, fontWeight: '600' },
  iconBox: { width: 56, height: 56, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
});
