import React from 'react';
import { Platform } from 'react-native';
import { Tabs } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp } from '../../src/store';
import { C } from '../../src/theme';
import { haptic } from '../../src/ui';

const ICONS = {
  index: ['home-variant', 'home-variant-outline'],
  tests: ['checkbox-marked-circle', 'checkbox-marked-circle-outline'],
  materials: ['book-open-page-variant', 'book-open-page-variant-outline'],
  profile: ['account-circle', 'account-circle-outline'],
  ai: ['robot-happy', 'robot-happy-outline'],
};

export default function TabsLayout() {
  const { t } = useApp();
  const insets = useSafeAreaInsets();
  return (
    <Tabs
      screenListeners={{ tabPress: () => haptic() }}
      screenOptions={({ route }) => ({
        headerShown: false,
        sceneStyle: { backgroundColor: C.bg },
        tabBarActiveTintColor: C.cyan,
        tabBarInactiveTintColor: C.muted,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '700' },
        tabBarStyle: {
          backgroundColor: '#081733',
          borderTopColor: C.border,
          height: 62 + Math.max(insets.bottom, Platform.OS === 'android' ? 8 : 0),
          paddingTop: 6,
          paddingBottom: Math.max(insets.bottom, 8),
        },
        tabBarIcon: ({ focused, color }) => (
          <MaterialCommunityIcons name={ICONS[route.name][focused ? 0 : 1]} size={25} color={color} />
        ),
      })}
    >
      <Tabs.Screen name="index" options={{ title: t('tabHome') }} />
      <Tabs.Screen name="tests" options={{ title: t('tabTests') }} />
      <Tabs.Screen name="materials" options={{ title: t('tabMaterials') }} />
      <Tabs.Screen name="profile" options={{ title: t('tabProfile') }} />
      <Tabs.Screen name="ai" options={{ title: t('tabAI') }} />
    </Tabs>
  );
}
