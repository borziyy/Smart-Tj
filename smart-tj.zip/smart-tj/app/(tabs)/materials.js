import React, { useState } from 'react';
import { LayoutAnimation, Platform, Pressable, ScrollView, StyleSheet, Text, UIManager, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Header, haptic, Screen, SubjectIcon } from '../../src/ui';
import { useApp } from '../../src/store';
import { MATERIALS } from '../../src/data/materials';
import { C, SUBJECTS, SUBJECT_KEYS } from '../../src/theme';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function Materials() {
  const { t, lang } = useApp();
  const [subject, setSubject] = useState('math');
  const [open, setOpen] = useState(0);
  const topics = MATERIALS[subject];
  const color = SUBJECTS[subject].color;

  const toggle = (i) => {
    haptic();
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setOpen(open === i ? -1 : i);
  };

  return (
    <Screen>
      <Header title={t('tabMaterials')} />
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <Text style={s.h1}>{t('materials')}</Text>
        <Text style={s.sub}>{t('materialsSub')}</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chips}>
          {SUBJECT_KEYS.map((k) => {
            const active = k === subject;
            return (
              <Pressable
                key={k}
                onPress={() => {
                  haptic();
                  setSubject(k);
                  setOpen(0);
                }}
                style={[s.chip, active && { backgroundColor: SUBJECTS[k].color, borderColor: SUBJECTS[k].color }]}
              >
                <MaterialCommunityIcons name={SUBJECTS[k].icon} size={18} color="#fff" />
                <Text style={s.chipText}>{t(k)}</Text>
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={s.summary}>
          <SubjectIcon subject={subject} size={40} />
          <Text style={s.summaryText}>
            {t(subject)} · {topics.length} {t('topics')}
          </Text>
        </View>

        {topics.map((topic, i) => {
          const T = topic[lang];
          const isOpen = open === i;
          return (
            <Card key={`${subject}-${i}`} style={[s.topic, isOpen && { borderColor: color }]}>
              <Pressable onPress={() => toggle(i)} style={s.topicHead}>
                <View style={[s.num, { backgroundColor: isOpen ? color : 'rgba(255,255,255,0.07)' }]}>
                  <Text style={s.numText}>{i + 1}</Text>
                </View>
                <Text style={s.topicTitle}>{T.title}</Text>
                <MaterialCommunityIcons name={isOpen ? 'chevron-up' : 'chevron-down'} size={24} color={C.muted} />
              </Pressable>
              {isOpen && (
                <View style={s.items}>
                  {T.items.map(([k, v], j) => (
                    <View key={j} style={s.item}>
                      <Text style={[s.formula, { color }]}>{k}</Text>
                      <Text style={s.desc}>{v}</Text>
                    </View>
                  ))}
                </View>
              )}
            </Card>
          );
        })}
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  scroll: { paddingHorizontal: 20, paddingBottom: 30 },
  h1: { color: C.text, fontSize: 30, fontWeight: '900', marginTop: 4 },
  sub: { color: C.textDim, fontSize: 14, marginTop: 4, marginBottom: 16, fontWeight: '600' },
  chips: { gap: 8, paddingBottom: 4 },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, height: 40,
    borderRadius: 20, borderWidth: 1, borderColor: C.border, backgroundColor: C.card,
  },
  chipText: { color: '#fff', fontWeight: '800', fontSize: 14 },
  summary: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 18 },
  summaryText: { color: C.text, fontSize: 17, fontWeight: '800' },
  topic: { marginBottom: 10, padding: 0, overflow: 'hidden' },
  topicHead: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  num: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  numText: { color: '#fff', fontWeight: '900' },
  topicTitle: { color: C.text, fontSize: 16, fontWeight: '800', flex: 1 },
  items: { paddingHorizontal: 14, paddingBottom: 14, gap: 8 },
  item: { backgroundColor: 'rgba(7,18,43,0.5)', borderRadius: 12, padding: 12 },
  formula: { fontSize: 17, fontWeight: '800' },
  desc: { color: C.textDim, fontSize: 14, marginTop: 3, lineHeight: 20 },
});
