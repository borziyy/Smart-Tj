import React, { useRef, useState } from 'react';
import {
  ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Header, haptic, Screen } from '../../src/ui';
import { useApp } from '../../src/store';
import { ask, hasOnline } from '../../src/ai';
import { C, R } from '../../src/theme';

export default function AI() {
  const { t, lang } = useApp();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [online, setOnline] = useState(hasOnline());
  const scrollRef = useRef(null);

  const send = async (textArg) => {
    const text = (textArg ?? input).trim();
    if (!text || busy) return;
    haptic();
    setInput('');
    const history = messages.map((m) => ({ role: m.role, content: m.text }));
    setMessages((m) => [...m, { role: 'user', text }]);
    setBusy(true);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 50);
    const res = await ask(text, lang, history);
    setOnline(res.source === 'online');
    setMessages((m) => [...m, { role: 'assistant', text: res.text || t('aiNotFound'), source: res.source }]);
    setBusy(false);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 80);
  };

  const examples = [t('aiEx1'), t('aiEx2'), t('aiEx3')];

  return (
    <Screen>
      <Header
        title={t('aiTitle')}
        right={
          <View style={[s.status, { borderColor: online ? 'rgba(34,197,94,0.5)' : C.border }]}>
            <View style={[s.dot, { backgroundColor: online ? C.success : C.gold }]} />
            <Text style={s.statusText}>{online ? t('aiOnline') : t('aiOffline')}</Text>
          </View>
        }
      />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={90}>
        <ScrollView ref={scrollRef} contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
          <LinearGradient colors={['#2563EB', '#1E3A8A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
            <View style={s.robot}>
              <MaterialCommunityIcons name="robot-happy-outline" size={40} color="#fff" />
            </View>
            <Text style={s.heroTitle}>{t('aiTitle')}</Text>
            <Text style={s.heroSub}>{t('aiSub')}</Text>
          </LinearGradient>

          <View style={s.bubbleAi}>
            <Text style={s.aiText}>{t('aiHello')}</Text>
          </View>

          {messages.length === 0 && (
            <View style={{ marginTop: 6 }}>
              <Text style={s.exLabel}>{t('aiExamples')}:</Text>
              <View style={s.exWrap}>
                {examples.map((e) => (
                  <Pressable key={e} onPress={() => send(e)} style={s.ex}>
                    <MaterialCommunityIcons name="lightning-bolt" size={14} color={C.cyan} />
                    <Text style={s.exText}>{e}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
          )}

          {messages.map((m, i) =>
            m.role === 'user' ? (
              <LinearGradient key={i} colors={['#3B82F6', '#2563EB']} style={s.bubbleUser}>
                <Text style={s.userText}>{m.text}</Text>
              </LinearGradient>
            ) : (
              <View key={i} style={s.bubbleAi}>
                <Text style={s.aiText} selectable>{m.text}</Text>
                {m.source === 'offline' && <Text style={s.src}>⚡ {t('aiFromBase')}</Text>}
              </View>
            )
          )}

          {busy && (
            <View style={[s.bubbleAi, { flexDirection: 'row', alignItems: 'center', gap: 10 }]}>
              <ActivityIndicator color={C.cyan} />
              <Text style={s.aiText}>{t('aiThinking')}</Text>
            </View>
          )}

          {messages.length > 0 && !busy && (
            <Pressable onPress={() => setMessages([])} style={s.clear}>
              <MaterialCommunityIcons name="broom" size={16} color={C.muted} />
              <Text style={s.clearText}>{t('clearChat')}</Text>
            </Pressable>
          )}
        </ScrollView>

        <View style={s.inputBar}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder={t('aiPlaceholder')}
            placeholderTextColor={C.muted}
            style={s.input}
            multiline
            maxLength={1000}
            onSubmitEditing={() => send()}
          />
          <Pressable onPress={() => send()} disabled={busy || !input.trim()} style={{ opacity: busy || !input.trim() ? 0.5 : 1 }}>
            <LinearGradient colors={['#38D5F5', '#3B82F6']} style={s.sendBtn}>
              <MaterialCommunityIcons name="send" size={22} color="#fff" />
            </LinearGradient>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const s = StyleSheet.create({
  status: {
    flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, height: 32,
    borderRadius: 16, borderWidth: 1, backgroundColor: 'rgba(255,255,255,0.04)',
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { color: C.text, fontSize: 12, fontWeight: '700' },
  scroll: { paddingHorizontal: 20, paddingBottom: 20 },
  hero: { borderRadius: R.xl, padding: 20, alignItems: 'center', marginBottom: 16 },
  robot: {
    width: 70, height: 70, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center', justifyContent: 'center',
  },
  heroTitle: { color: '#fff', fontSize: 22, fontWeight: '900', marginTop: 10 },
  heroSub: { color: '#DCE8FF', fontSize: 14, textAlign: 'center', marginTop: 4, lineHeight: 20 },
  bubbleAi: {
    alignSelf: 'flex-start', maxWidth: '92%', backgroundColor: C.card, borderWidth: 1, borderColor: C.border,
    borderRadius: 18, borderTopLeftRadius: 6, padding: 14, marginBottom: 10,
  },
  aiText: { color: C.text, fontSize: 15.5, lineHeight: 23 },
  src: { color: C.muted, fontSize: 12, marginTop: 8, fontWeight: '700' },
  bubbleUser: {
    alignSelf: 'flex-end', maxWidth: '85%', borderRadius: 18, borderTopRightRadius: 6, padding: 14, marginBottom: 10,
  },
  userText: { color: '#fff', fontSize: 15.5, lineHeight: 22, fontWeight: '600' },
  exLabel: { color: C.muted, fontSize: 13, fontWeight: '700', marginBottom: 8 },
  exWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  ex: {
    flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9,
    borderRadius: 14, borderWidth: 1, borderColor: C.borderHi, backgroundColor: 'rgba(56,213,245,0.08)',
  },
  exText: { color: C.text, fontSize: 13.5, fontWeight: '600' },
  clear: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'center', padding: 8 },
  clearText: { color: C.muted, fontSize: 13, fontWeight: '700' },
  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 10, paddingHorizontal: 16, paddingVertical: 10,
    borderTopWidth: 1, borderTopColor: C.border, backgroundColor: '#081733',
  },
  input: {
    flex: 1, minHeight: 48, maxHeight: 120, borderRadius: 16, paddingHorizontal: 14, paddingTop: 13, paddingBottom: 12,
    backgroundColor: C.card, color: C.text, fontSize: 15.5, borderWidth: 1, borderColor: C.border,
  },
  sendBtn: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
});
