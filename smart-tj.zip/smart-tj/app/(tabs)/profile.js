import React from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Header, Press, ProgressBar, Screen, SectionTitle } from '../../src/ui';
import { useApp } from '../../src/store';
import { DB } from '../../src/data';
import { APP_VERSION, AUTHOR, AUTHOR_INITIALS, C, R, SUBJECTS, SUBJECT_KEYS } from '../../src/theme';

const LANGS = [
  { key: 'tj', label: 'Тоҷикӣ', flag: '🇹🇯' },
  { key: 'ru', label: 'Русский', flag: '🇷🇺' },
];

export default function Profile() {
  const { t, lang, setLang, state, resetStats } = useApp();
  const acc = state.answered ? Math.round((state.correct / state.answered) * 100) : 0;

  const askReset = () => {
    if (Platform.OS === 'web') {
      // eslint-disable-next-line no-alert
      if (window.confirm(t('resetMsg'))) resetStats();
      return;
    }
    Alert.alert(t('resetTitle'), t('resetMsg'), [
      { text: t('cancel'), style: 'cancel' },
      { text: t('reset'), style: 'destructive', onPress: resetStats },
    ]);
  };

  return (
    <Screen>
      <Header title={t('profile')} />
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#2563EB', '#1E3A8A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
          <LinearGradient colors={['#4F8DFF', '#1D4ED8']} style={s.avatar}>
            <Text style={s.avatarText}>{AUTHOR_INITIALS}</Text>
          </LinearGradient>
          <Text style={s.name}>{AUTHOR}</Text>
          <Text style={s.role}>{t('author')}</Text>
          <View style={s.pill}>
            <Text style={s.pillText}>SMART TJ · EDUCATION</Text>
          </View>
        </LinearGradient>

        <SectionTitle style={{ marginTop: 22 }}>{t('myStats')}</SectionTitle>
        <View style={s.grid}>
          {[
            { v: state.testsTaken, l: t('testsTaken'), icon: 'clipboard-check-outline', c: C.cyan },
            { v: state.correct, l: t('correctAnswers'), icon: 'check-decagram-outline', c: C.success },
            { v: `${state.best}%`, l: t('bestScore'), icon: 'trophy-outline', c: C.gold },
            { v: `${acc}%`, l: t('accuracy'), icon: 'bullseye-arrow', c: '#A855F7' },
          ].map((x, i) => (
            <Card key={i} style={s.stat}>
              <MaterialCommunityIcons name={x.icon} size={24} color={x.c} />
              <Text style={s.statNum}>{x.v}</Text>
              <Text style={s.statLbl}>{x.l}</Text>
            </Card>
          ))}
        </View>

        <SectionTitle style={{ marginTop: 18 }}>{t('bySubject')}</SectionTitle>
        <Card style={{ gap: 14 }}>
          {SUBJECT_KEYS.map((k) => {
            const st = state.subjects[k];
            const total = DB.bySubject[k].length;
            return (
              <View key={k}>
                <View style={s.rowBetween}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <MaterialCommunityIcons name={SUBJECTS[k].icon} size={20} color={SUBJECTS[k].color} />
                    <Text style={s.subName}>{t(k)}</Text>
                  </View>
                  <Text style={s.subVal}>
                    {st.learned.length} / {total}
                  </Text>
                </View>
                <View style={{ height: 8 }} />
                <ProgressBar value={st.learned.length / total} color={SUBJECTS[k].color} height={8} />
              </View>
            );
          })}
        </Card>

        <SectionTitle style={{ marginTop: 18 }}>{t('language')}</SectionTitle>
        {LANGS.map((l) => {
          const active = lang === l.key;
          return (
            <Press key={l.key} onPress={() => setLang(l.key)} style={{ marginBottom: 10 }}>
              <Card hi={active} style={s.langRow}>
                <Text style={{ fontSize: 22 }}>{l.flag}</Text>
                <Text style={s.langText}>{l.label}</Text>
                {active && <MaterialCommunityIcons name="check-circle" size={24} color={C.cyan} />}
              </Card>
            </Press>
          );
        })}

        <SectionTitle style={{ marginTop: 18 }}>{t('history')}</SectionTitle>
        {state.history.length === 0 ? (
          <Card>
            <Text style={s.muted}>{t('noHistory')}</Text>
          </Card>
        ) : (
          state.history.slice(0, 8).map((h, i) => {
            const d = new Date(h.date);
            const color = h.percent >= 85 ? C.success : h.percent >= 50 ? C.cyan : C.danger;
            return (
              <Card key={i} style={s.hist}>
                <View style={[s.histPct, { borderColor: color }]}>
                  <Text style={[s.histPctText, { color }]}>{h.percent}%</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={s.histTitle}>{h.title}</Text>
                  <Text style={s.muted}>
                    {h.correct}/{h.total} · {d.getDate()}.{String(d.getMonth() + 1).padStart(2, '0')}.{d.getFullYear()}
                  </Text>
                </View>
              </Card>
            );
          })
        )}

        <Card style={{ marginTop: 18 }}>
          <Text style={s.aboutTitle}>SMART TJ</Text>
          <Text style={s.aboutText}>{t('about')}</Text>
          <Text style={s.muted}>
            {t('version')} {APP_VERSION} · © {new Date().getFullYear()} {AUTHOR}
          </Text>
        </Card>

        <Press onPress={askReset} style={s.reset}>
          <MaterialCommunityIcons name="delete-outline" size={20} color={C.danger} />
          <Text style={s.resetText}>{t('resetStats')}</Text>
        </Press>
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  scroll: { paddingHorizontal: 20, paddingBottom: 30 },
  hero: { borderRadius: R.xl, padding: 24, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(160,210,255,0.35)' },
  avatar: {
    width: 92, height: 92, borderRadius: 28, alignItems: 'center', justifyContent: 'center',
    borderWidth: 3, borderColor: 'rgba(160,220,255,0.85)',
  },
  avatarText: { color: '#fff', fontSize: 36, fontWeight: '900' },
  name: { color: '#fff', fontSize: 24, fontWeight: '900', marginTop: 14, letterSpacing: 1 },
  role: { color: '#DCE8FF', fontSize: 15, fontWeight: '600', marginTop: 4 },
  pill: { marginTop: 12, backgroundColor: 'rgba(56,213,245,0.22)', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 6 },
  pillText: { color: C.cyan, fontWeight: '900', letterSpacing: 1, fontSize: 13 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 10 },
  stat: { width: '48.5%', gap: 4, paddingVertical: 14 },
  statNum: { color: C.text, fontSize: 24, fontWeight: '900', marginTop: 4 },
  statLbl: { color: C.muted, fontSize: 13, fontWeight: '700' },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  subName: { color: C.text, fontSize: 15, fontWeight: '700' },
  subVal: { color: C.textDim, fontSize: 13, fontWeight: '700' },
  langRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14 },
  langText: { color: C.text, fontSize: 17, fontWeight: '700', flex: 1 },
  muted: { color: C.muted, fontSize: 13, fontWeight: '600' },
  hist: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 8, paddingVertical: 12 },
  histPct: { width: 54, height: 54, borderRadius: 27, borderWidth: 3, alignItems: 'center', justifyContent: 'center' },
  histPctText: { fontWeight: '900', fontSize: 14 },
  histTitle: { color: C.text, fontSize: 15, fontWeight: '800', marginBottom: 2 },
  aboutTitle: { color: C.cyan, fontSize: 18, fontWeight: '900' },
  aboutText: { color: C.textDim, fontSize: 14, lineHeight: 20, marginVertical: 6 },
  reset: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 16,
    height: 48, borderRadius: 14, borderWidth: 1, borderColor: 'rgba(240,82,82,0.35)',
  },
  resetText: { color: C.danger, fontWeight: '800', fontSize: 15 },
});
