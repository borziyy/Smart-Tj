import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Header, Press, ProgressBar, Screen, SectionTitle, SubjectIcon } from '../../src/ui';
import { useApp } from '../../src/store';
import { DB, TOTAL_QUESTIONS } from '../../src/data';
import { AUTHOR, C, R, SUBJECTS, SUBJECT_KEYS } from '../../src/theme';

export default function Home() {
  const { t, state } = useApp();
  const learnedTotal = SUBJECT_KEYS.reduce((n, k) => n + state.subjects[k].learned.length, 0);

  return (
    <Screen>
      <Header title="Smart TJ" />
      <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#2563EB', '#1E3A8A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
          <View style={s.heroBubble} />
          <Text style={s.hello}>{t('hello')}</Text>
          <Text style={s.name}>{AUTHOR}</Text>
          <Text style={s.welcome}>{t('welcome')}</Text>

          <View style={s.heroRow}>
            <View style={s.heroStat}>
              <MaterialCommunityIcons name="fire" size={22} color={C.gold} />
              <Text style={s.heroNum}>{state.streak}</Text>
              <Text style={s.heroLbl}>{t('streak')}</Text>
            </View>
            <View style={s.heroStat}>
              <MaterialCommunityIcons name="trophy-outline" size={22} color={C.gold} />
              <Text style={s.heroNum}>{state.best}%</Text>
              <Text style={s.heroLbl}>{t('bestScore')}</Text>
            </View>
          </View>

          <View style={{ marginTop: 16 }}>
            <View style={s.rowBetween}>
              <Text style={s.heroLbl}>{t('overall')}</Text>
              <Text style={s.heroLbl}>
                {learnedTotal} / {TOTAL_QUESTIONS} {t('learned')}
              </Text>
            </View>
            <View style={{ height: 8 }} />
            <ProgressBar value={learnedTotal / TOTAL_QUESTIONS} color={C.cyan} height={8} track="rgba(255,255,255,0.18)" />
          </View>
        </LinearGradient>

        <SectionTitle style={{ marginTop: 22 }}>{t('quickStart')}</SectionTitle>

        <Press onPress={() => router.push({ pathname: '/quiz', params: { mode: 'olympiad' } })}>
          <LinearGradient colors={['#F59E0B', '#EA580C']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.bigAction}>
            <View style={s.actionIcon}>
              <MaterialCommunityIcons name="medal-outline" size={30} color="#fff" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.actionTitle}>{t('olympiad')}</Text>
              <Text style={s.actionSub}>{t('olympiadDesc')}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
          </LinearGradient>
        </Press>

        <View style={s.twoCol}>
          <Press style={{ flex: 1 }} onPress={() => router.push({ pathname: '/quiz', params: { mode: 'random' } })}>
            <Card style={s.smallAction}>
              <MaterialCommunityIcons name="shuffle-variant" size={28} color={C.cyan} />
              <Text style={s.smallTitle}>{t('random')}</Text>
              <Text style={s.smallSub}>{t('randomDesc')}</Text>
            </Card>
          </Press>
          <Press style={{ flex: 1 }} onPress={() => router.push({ pathname: '/quiz', params: { mode: 'mistakes' } })}>
            <Card style={s.smallAction}>
              <View style={s.rowBetween}>
                <MaterialCommunityIcons name="target" size={28} color={C.danger} />
                {state.mistakes.length > 0 && (
                  <View style={s.badge}>
                    <Text style={s.badgeText}>{state.mistakes.length}</Text>
                  </View>
                )}
              </View>
              <Text style={s.smallTitle}>{t('mistakes')}</Text>
              <Text style={s.smallSub}>{t('mistakesDesc')}</Text>
            </Card>
          </Press>
        </View>

        <SectionTitle style={{ marginTop: 22 }}>{t('subjects')}</SectionTitle>
        <View style={s.grid}>
          {SUBJECT_KEYS.map((k) => {
            const total = DB.bySubject[k].length;
            const learned = state.subjects[k].learned.length;
            return (
              <Press key={k} style={s.gridItem} onPress={() => router.push({ pathname: '/subject', params: { subject: k } })}>
                <Card style={{ padding: 14 }}>
                  <SubjectIcon subject={k} size={46} />
                  <Text style={s.subTitle}>{t(k)}</Text>
                  <Text style={s.subCount}>
                    {total} {t('questions')}
                  </Text>
                  <ProgressBar value={learned / total} color={SUBJECTS[k].color} />
                  <Text style={s.subPct}>{Math.round((learned / total) * 100)}%</Text>
                </Card>
              </Press>
            );
          })}
        </View>

        <Text style={s.footer}>
          SMART TJ · {t('author')}: {AUTHOR}
        </Text>
      </ScrollView>
    </Screen>
  );
}

const s = StyleSheet.create({
  scroll: { paddingHorizontal: 20, paddingBottom: 30 },
  hero: { borderRadius: R.xl, padding: 20, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(160,210,255,0.35)' },
  heroBubble: {
    position: 'absolute', right: -50, top: -50, width: 180, height: 180, borderRadius: 90,
    backgroundColor: 'rgba(56, 213, 245, 0.18)',
  },
  hello: { color: '#DCE8FF', fontSize: 15, fontWeight: '600' },
  name: { color: '#fff', fontSize: 25, fontWeight: '900', letterSpacing: 0.8, marginTop: 2 },
  welcome: { color: '#C9DAFF', fontSize: 14, marginTop: 4 },
  heroRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
  heroStat: {
    flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap',
    backgroundColor: 'rgba(7, 18, 43, 0.35)', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10,
  },
  heroNum: { color: '#fff', fontSize: 18, fontWeight: '900' },
  heroLbl: { color: '#C9DAFF', fontSize: 12, fontWeight: '600' },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  bigAction: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderRadius: R.lg },
  actionIcon: {
    width: 52, height: 52, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.22)',
    alignItems: 'center', justifyContent: 'center',
  },
  actionTitle: { color: '#fff', fontSize: 18, fontWeight: '900' },
  actionSub: { color: 'rgba(255,255,255,0.9)', fontSize: 13, marginTop: 2, fontWeight: '600' },
  twoCol: { flexDirection: 'row', gap: 12, marginTop: 12 },
  smallAction: { minHeight: 128, gap: 6 },
  smallTitle: { color: C.text, fontSize: 15, fontWeight: '800', marginTop: 4 },
  smallSub: { color: C.muted, fontSize: 12, fontWeight: '600' },
  badge: { backgroundColor: C.danger, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  badgeText: { color: '#fff', fontWeight: '800', fontSize: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 12 },
  gridItem: { width: '48.3%' },
  subTitle: { color: C.text, fontSize: 16, fontWeight: '800', marginTop: 12 },
  subCount: { color: C.muted, fontSize: 12, fontWeight: '600', marginTop: 2, marginBottom: 10 },
  subPct: { color: C.textDim, fontSize: 12, fontWeight: '700', marginTop: 6 },
  footer: { color: C.muted, textAlign: 'center', fontSize: 12, marginTop: 26, fontWeight: '600' },
});
