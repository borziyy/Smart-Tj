import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Animated, BackHandler, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, GhostButton, haptic, Press, PrimaryButton, ProgressBar, Screen, SubjectIcon } from '../src/ui';
import { useApp } from '../src/store';
import { DB, prepare, shuffled } from '../src/data';
import { C, R, SUBJECTS, SUBJECT_KEYS } from '../src/theme';
import { OLYMPIAD_QUESTIONS, OLYMPIAD_SECONDS } from '../src/config';
import { setLastResult } from '../src/session';

const LETTERS = ['A', 'B', 'C', 'D'];

function buildQuestions(mode, subject, count, state) {
  let list = [];
  if (mode === 'subject') {
    const learned = new Set(state.subjects[subject]?.learned || []);
    const pool = DB.bySubject[subject] || [];
    const fresh = shuffled(pool.filter((q) => !learned.has(q.id)));
    const old = shuffled(pool.filter((q) => learned.has(q.id)));
    list = shuffled([...fresh, ...old].slice(0, count));
  } else if (mode === 'olympiad') {
    const per = Math.ceil(OLYMPIAD_QUESTIONS / SUBJECT_KEYS.length);
    SUBJECT_KEYS.forEach((k) => list.push(...shuffled(DB.bySubject[k]).slice(0, per)));
    list = shuffled(list).slice(0, OLYMPIAD_QUESTIONS);
  } else if (mode === 'mistakes') {
    list = shuffled(state.mistakes.map((id) => DB.byId[id]).filter(Boolean)).slice(0, 30);
  } else {
    list = shuffled(DB.all).slice(0, 15);
  }
  return list.map(prepare);
}

function mmss(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

export default function Quiz() {
  const params = useLocalSearchParams();
  const mode = params.mode || 'random';
  const subject = params.subject;
  const count = Number(params.count || 10);
  const { t, lang, state, recordTest } = useApp();

  // вопросы фиксируются один раз при открытии
  const questions = useMemo(() => buildQuestions(mode, subject, count, state), []); // eslint-disable-line
  const [idx, setIdx] = useState(0);
  const [picked, setPicked] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [elapsed, setElapsed] = useState(0);
  const finished = useRef(false);
  const anim = useRef(new Animated.Value(1)).current;
  const scrollRef = useRef(null);

  const isOlympiad = mode === 'olympiad';
  const remaining = OLYMPIAD_SECONDS - elapsed;
  const q = questions[idx];

  const title =
    mode === 'subject' ? t(subject) : mode === 'olympiad' ? t('olympiad') : mode === 'mistakes' ? t('mistakes') : t('random');

  const finish = useCallback(
    (finalAnswers, timeUp = false) => {
      if (finished.current) return;
      finished.current = true;
      const answeredIds = new Set(finalAnswers.map((a) => a.id));
      const all = [...finalAnswers];
      if (timeUp) {
        questions.forEach((qq) => {
          if (!answeredIds.has(qq.id)) all.push({ id: qq.id, subject: qq.subject, correct: false, picked: null, q: qq });
        });
      }
      const correct = all.filter((a) => a.correct).length;
      const total = questions.length;
      const percent = Math.round((correct / Math.max(1, total)) * 100);
      const isRecord = total >= 5 && percent > state.best;
      recordTest({
        title,
        subject: mode === 'subject' ? subject : null,
        total,
        seconds: elapsed,
        answers: all.map((a) => ({ id: a.id, subject: a.subject, correct: a.correct })),
      });
      setLastResult({ title, mode, subject, total, correct, percent, seconds: elapsed, isRecord, timeUp, answers: all });
      router.replace('/result');
    },
    [questions, elapsed, state.best, recordTest, title, mode, subject]
  );

  // таймер
  useEffect(() => {
    const id = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (isOlympiad && remaining <= 0 && !finished.current) {
      haptic('error');
      finish(answers, true);
    }
  }, [remaining, isOlympiad, answers, finish]);

  const confirmExit = useCallback(() => {
    if (answers.length === 0) {
      router.back();
      return true;
    }
    if (Platform.OS === 'web') {
      // eslint-disable-next-line no-alert
      if (window.confirm(`${t('exitTitle')}\n${t('exitMsg')}`)) router.back();
      return true;
    }
    Alert.alert(t('exitTitle'), t('exitMsg'), [
      { text: t('cancel'), style: 'cancel' },
      { text: t('exit'), style: 'destructive', onPress: () => router.back() },
    ]);
    return true;
  }, [answers.length, t]);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', confirmExit);
    return () => sub.remove();
  }, [confirmExit]);

  if (!questions.length) {
    return (
      <Screen edges={['top', 'bottom']}>
        <View style={s.empty}>
          <MaterialCommunityIcons name="emoticon-happy-outline" size={72} color={C.cyan} />
          <Text style={s.emptyText}>{t('noMistakes')}</Text>
          <PrimaryButton title={t('home')} icon="home-variant" onPress={() => router.back()} style={{ alignSelf: 'stretch' }} />
        </View>
      </Screen>
    );
  }

  const L = q[lang];
  const answered = picked !== null;

  const choose = (pos) => {
    if (answered) return;
    const ok = pos === q.correctPos;
    haptic(ok ? 'success' : 'error');
    setPicked(pos);
    setAnswers((a) => [...a, { id: q.id, subject: q.subject, correct: ok, picked: pos, q }]);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 120);
  };

  const next = () => {
    if (idx + 1 >= questions.length) {
      finish(answers);
      return;
    }
    Animated.timing(anim, { toValue: 0, duration: 140, useNativeDriver: true }).start(() => {
      setIdx(idx + 1);
      setPicked(null);
      scrollRef.current?.scrollTo({ y: 0, animated: false });
      Animated.timing(anim, { toValue: 1, duration: 220, useNativeDriver: true }).start();
    });
  };

  const correctSoFar = answers.filter((a) => a.correct).length;
  const subjColor = SUBJECTS[q.subject].color;

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={s.top}>
        <Pressable onPress={confirmExit} hitSlop={12} style={s.iconBtn}>
          <MaterialCommunityIcons name="close" size={22} color={C.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={s.topTitle} numberOfLines={1}>{title}</Text>
          <Text style={s.topSub}>
            {t('question')} {idx + 1} / {questions.length} · ✓ {correctSoFar}
          </Text>
        </View>
        <View style={[s.timer, isOlympiad && remaining < 60 && { borderColor: C.danger }]}>
          <MaterialCommunityIcons name="clock-outline" size={16} color={isOlympiad && remaining < 60 ? C.danger : C.cyan} />
          <Text style={[s.timerText, isOlympiad && remaining < 60 && { color: C.danger }]}>
            {mmss(isOlympiad ? Math.max(0, remaining) : elapsed)}
          </Text>
        </View>
      </View>
      <View style={{ paddingHorizontal: 20 }}>
        <ProgressBar value={(idx + (answered ? 1 : 0)) / questions.length} color={C.cyan} height={6} />
      </View>

      <ScrollView ref={scrollRef} contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false}>
        <Animated.View
          style={{
            opacity: anim,
            transform: [{ translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }],
          }}
        >
          <View style={s.subjRow}>
            <SubjectIcon subject={q.subject} size={28} />
            <Text style={[s.subjText, { color: subjColor }]}>{t(q.subject)}</Text>
          </View>
          <Text style={s.question}>{L.q}</Text>

          {q.order.map((origIdx, pos) => {
            const isCorrect = pos === q.correctPos;
            const isPicked = pos === picked;
            let border = C.border;
            let bg = C.card;
            let letterBg = 'rgba(255,255,255,0.08)';
            let icon = null;
            if (answered) {
              if (isCorrect) {
                border = C.success;
                bg = C.successBg;
                letterBg = C.success;
                icon = 'check-circle';
              } else if (isPicked) {
                border = C.danger;
                bg = C.dangerBg;
                letterBg = C.danger;
                icon = 'close-circle';
              }
            }
            return (
              <Press key={pos} onPress={() => choose(pos)} disabled={answered} style={{ marginBottom: 10 }}>
                <View
                  style={[
                    s.option,
                    { borderColor: border, backgroundColor: bg },
                    answered && !isCorrect && !isPicked && { opacity: 0.5 },
                  ]}
                >
                  <View style={[s.letter, { backgroundColor: letterBg }]}>
                    <Text style={s.letterText}>{LETTERS[pos]}</Text>
                  </View>
                  <Text style={s.optionText}>{L.o[origIdx]}</Text>
                  {icon && <MaterialCommunityIcons name={icon} size={24} color={isCorrect ? C.success : C.danger} />}
                </View>
              </Press>
            );
          })}

          {answered && (
            <Card style={[s.explain, { borderColor: picked === q.correctPos ? C.success : C.danger }]}>
              <View style={s.explainHead}>
                <MaterialCommunityIcons
                  name={picked === q.correctPos ? 'party-popper' : 'lightbulb-on-outline'}
                  size={22}
                  color={picked === q.correctPos ? C.success : C.gold}
                />
                <Text style={[s.explainTitle, { color: picked === q.correctPos ? C.success : C.danger }]}>
                  {picked === q.correctPos ? t('correct') : `${t('wrong')} · ${t('correctAnswer')}: ${L.o[0]}`}
                </Text>
              </View>
              <Text style={s.explainLabel}>{t('explanation')}</Text>
              <Text style={s.explainText}>{L.e}</Text>
            </Card>
          )}
        </Animated.View>
      </ScrollView>

      <View style={s.bottom}>
        {answered ? (
          <PrimaryButton
            title={idx + 1 >= questions.length ? t('finish') : t('next')}
            icon={idx + 1 >= questions.length ? 'flag-checkered' : 'arrow-right'}
            onPress={next}
          />
        ) : (
          <GhostButton title={`${t('question')} ${idx + 1} / ${questions.length}`} icon="gesture-tap" onPress={() => {}} />
        )}
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingTop: 4, paddingBottom: 12 },
  iconBtn: {
    width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: C.border,
  },
  topTitle: { color: C.text, fontSize: 17, fontWeight: '800' },
  topSub: { color: C.muted, fontSize: 13, fontWeight: '600', marginTop: 2 },
  timer: {
    flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, height: 38,
    borderRadius: 12, borderWidth: 1, borderColor: C.borderHi, backgroundColor: 'rgba(56,213,245,0.08)',
  },
  timerText: { color: C.text, fontWeight: '800', fontSize: 15, fontVariant: ['tabular-nums'] },
  scroll: { paddingHorizontal: 20, paddingTop: 20, paddingBottom: 24 },
  subjRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  subjText: { fontWeight: '800', fontSize: 14 },
  question: { color: C.text, fontSize: 22, fontWeight: '800', lineHeight: 31, marginBottom: 20 },
  option: {
    flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderRadius: R.md, borderWidth: 1.5, minHeight: 60,
  },
  letter: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  letterText: { color: '#fff', fontWeight: '900', fontSize: 15 },
  optionText: { color: C.text, fontSize: 16.5, fontWeight: '600', flex: 1, lineHeight: 22 },
  explain: { marginTop: 8, borderWidth: 1.5 },
  explainHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  explainTitle: { fontSize: 15, fontWeight: '800', flex: 1 },
  explainLabel: { color: C.muted, fontSize: 12, fontWeight: '800', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 },
  explainText: { color: C.textDim, fontSize: 15, lineHeight: 22 },
  bottom: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 12 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30, gap: 20 },
  emptyText: { color: C.text, fontSize: 18, fontWeight: '700', textAlign: 'center' },
});
