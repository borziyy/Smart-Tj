import React, { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { Logo, Screen } from '../src/ui';
import { AUTHOR, C } from '../src/theme';
import { useApp } from '../src/store';

export default function Splash() {
  const { t, ready } = useApp();
  const logo = useRef(new Animated.Value(0)).current;
  const text = useRef(new Animated.Value(0)).current;
  const line = useRef(new Animated.Value(0)).current;
  const foot = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!ready) return;
    SplashScreen.hideAsync().catch(() => {});
    Animated.sequence([
      Animated.spring(logo, { toValue: 1, useNativeDriver: true, friction: 5, tension: 60 }),
      Animated.parallel([
        Animated.timing(text, { toValue: 1, duration: 450, useNativeDriver: true, easing: Easing.out(Easing.cubic) }),
        Animated.timing(line, { toValue: 1, duration: 600, useNativeDriver: false, easing: Easing.out(Easing.cubic) }),
      ]),
      Animated.timing(foot, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();
    const timer = setTimeout(() => router.replace('/(tabs)'), 2600);
    return () => clearTimeout(timer);
  }, [ready]);

  const logoStyle = {
    opacity: logo,
    transform: [
      { scale: logo.interpolate({ inputRange: [0, 1], outputRange: [0.4, 1] }) },
      { rotate: logo.interpolate({ inputRange: [0, 1], outputRange: ['-25deg', '0deg'] }) },
    ],
  };
  const up = (v) => ({
    opacity: v,
    transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }],
  });

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={s.center}>
        <Animated.View style={[s.logoWrap, logoStyle]}>
          <Logo size={112} />
        </Animated.View>
        <Animated.Text style={[s.title, up(text)]}>SMART TJ</Animated.Text>
        <Animated.View
          style={[s.line, { width: line.interpolate({ inputRange: [0, 1], outputRange: [0, 90] }) }]}
        />
        <Animated.Text style={[s.edu, up(text)]}>EDUCATION</Animated.Text>
        <Animated.Text style={[s.motto, up(text)]}>{t('motto')}</Animated.Text>
      </View>
      <Animated.View style={[s.footer, up(foot)]}>
        <Text style={s.authorLabel}>{t('author')}</Text>
        <Text style={s.author}>{AUTHOR}</Text>
      </Animated.View>
    </Screen>
  );
}

const s = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  logoWrap: {
    shadowColor: '#3B82F6',
    shadowOpacity: 0.7,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: 0 },
    elevation: 20,
    marginBottom: 28,
  },
  title: { color: C.text, fontSize: 44, fontWeight: '900', letterSpacing: 4 },
  line: { height: 4, borderRadius: 2, backgroundColor: C.cyan, marginVertical: 14 },
  edu: { color: C.cyan, fontSize: 18, fontWeight: '800', letterSpacing: 8 },
  motto: { color: C.textDim, fontSize: 16, marginTop: 14, fontWeight: '600' },
  footer: { alignItems: 'center', paddingBottom: 28 },
  authorLabel: { color: C.muted, fontSize: 13, fontWeight: '600', marginBottom: 4 },
  author: { color: C.cyan, fontSize: 20, fontWeight: '900', letterSpacing: 1.5 },
});
