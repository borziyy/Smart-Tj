import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card, Press, PrimaryButton, Screen, SubjectIcon } from '../src/ui';
import { useApp } from '../src/store';
import { DB } from '../src/data';
import { C, R, SUBJECTS } from '../src/theme';

export default function Subject() {
  const { subject = 'math' } = useLocalSearchParams();
  const { t, state } = useApp();
  const total = DB.bySubject[subject]?.length ?? 0;
  const st = state.subjects[subject];
  const color = SUBJECTS[subject].color;

  const modes = [
    { count: 10, title: t('quick'), sub: t('q10'), icon: 'lightning-bolt-outline' },
    { count: 20, title: t('standard'), sub: t('q20'), icon: 'clipboard-text-outline' },
    { count: 40, title: t('marathon'), sub: t('q40'), icon: 'run-fast' },
    { count: total, title: t('full'), sub: `${t('qAll')} · ${total}`, icon: 'infinity' },
  ];
  const [sel, setSel] = useState(1);

  return (
    <Screen edges={['top', 'bottom']}>
      <View style={s.top}>
        <Pressable onPress={() => router.back()} hitSlop={12} style={s.back}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={C.text} />
        </Pressable>
      </View>
      <ScrollView contentContainerStyle={s.scroll}>
        <LinearGradient colors={SUBJECTS[subject].grad} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={s.hero}>
          <SubjectIcon subject={subject} size={70} />
          <Text style={s.title}>{t(subject)}</Text>
          <Text style={s.meta}>
            {total} {t('questions')} · {st.learned.length} {t('learned')}
          </Text>
        </LinearGradient>

        <Text style={s.choose}>{t('chooseMode')}</Text>
        {modes.map((m, i) => (
          <Press key={i} onPress={() => setSel(i)} style={{ marginBottom: 10 }}>
            <Card style={[s.mode, sel === i && { borderColor: color, backgroundColor: C.card2 }]}>
              <View style={[s.modeIcon, { backgroundColor: sel === i ? color : 'rgba(255,255,255,0.06)' }]}>
                <MaterialCommunityIcons name={m.icon} size={24} color="#fff" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.modeTitle}>{m.title}</Text>
                <Text style={s.modeSub}>{m.sub}</Text>
              </View>
              <MaterialCommunityIcons
                name={sel === i ? 'radiobox-marked' : 'radiobox-blank'}
                size={24}
                color={sel === i ? color : C.muted}
              />
            </Card>
          </Press>
        ))}
      </ScrollView>
      <View style={s.bottom}>
        <PrimaryButton
          title={t('start')}
          icon="play"
          colors={SUBJECTS[subject].grad}
          onPress={() =>
            router.replace({ pathname: '/quiz', params: { mode: 'subject', subject, count: String(modes[sel].count) } })
          }
        />
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  top: { paddingHorizontal: 16, paddingTop: 4, paddingBottom: 8 },
  back: {
    width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: C.border,
  },
  scroll: { paddingHorizontal: 20, paddingBottom: 20 },
  hero: { borderRadius: R.xl, padding: 22, alignItems: 'center' },
  title: { color: '#fff', fontSize: 28, fontWeight: '900', marginTop: 12 },
  meta: { color: 'rgba(255,255,255,0.9)', fontSize: 14, fontWeight: '600', marginTop: 4 },
  choose: { color: C.text, fontSize: 17, fontWeight: '800', marginTop: 22, marginBottom: 12 },
  mode: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14 },
  modeIcon: { width: 46, height: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  modeTitle: { color: C.text, fontSize: 16, fontWeight: '800' },
  modeSub: { color: C.muted, fontSize: 13, fontWeight: '600', marginTop: 2 },
  bottom: { paddingHorizontal: 20, paddingBottom: 12, paddingTop: 8 },
});
