// Smart TJ — сервер AI-помощника (Cloudflare Worker).
// Ключ API хранится ТОЛЬКО здесь (в секретах Cloudflare), а не в приложении.
//
// Секреты (Settings → Variables → Secrets):
//   ANTHROPIC_API_KEY  — ключ Claude API (console.anthropic.com)   ИЛИ
//   GEMINI_API_KEY     — ключ Google Gemini (aistudio.google.com, есть бесплатный лимит)
// Необязательно:
//   CLAUDE_MODEL (по умолчанию claude-haiku-5-5), GEMINI_MODEL (по умолчанию gemini-2.5-flash)

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};

function systemPrompt(lang) {
  const language = lang === 'tj' ? 'таджикском языке (кириллица)' : 'русском языке';
  return (
    'Ты — AI-помощник образовательного приложения Smart TJ (автор приложения — AKHUNOV BOZORBOY). ' +
    'Ты помогаешь школьникам Таджикистана готовиться к олимпиадам по математике, физике, химии и биологии. ' +
    `Отвечай на ${language}. Объясняй по шагам, просто и понятно, как хороший учитель. ` +
    'Для задач: сначала «Дано», затем формула, затем вычисления и ответ. ' +
    'Используй символы Unicode для формул (x², √, π, ≈, ·), без LaTeX и без Markdown-таблиц. ' +
    'Будь кратким: обычно до 12 строк. Если вопрос не про учёбу — вежливо верни разговор к учёбе.'
  );
}

async function askClaude(env, question, lang, history) {
  const messages = [...history, { role: 'user', content: question }];
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-api-key': env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: env.CLAUDE_MODEL || 'claude-haiku-5-5',
      max_tokens: 900,
      system: systemPrompt(lang),
      messages,
    }),
  });
  if (!res.ok) throw new Error('claude ' + res.status + ' ' + (await res.text()));
  const data = await res.json();
  return (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim();
}

async function askGemini(env, question, lang, history) {
  const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
  const contents = [...history, { role: 'user', content: question }].map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${env.GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt(lang) }] },
        contents,
        generationConfig: { maxOutputTokens: 900, temperature: 0.4 },
      }),
    }
  );
  if (!res.ok) throw new Error('gemini ' + res.status + ' ' + (await res.text()));
  const data = await res.json();
  return (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('\n').trim();
}

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...CORS } });
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { headers: CORS });
    if (request.method !== 'POST') return json({ ok: true, service: 'smart-tj-ai' });

    let body;
    try {
      body = await request.json();
    } catch (e) {
      return json({ error: 'bad json' }, 400);
    }
    const question = String(body.question || '').slice(0, 1000).trim();
    const lang = body.lang === 'ru' ? 'ru' : 'tj';
    if (!question) return json({ error: 'empty question' }, 400);

    // история: только корректные чередующиеся сообщения, максимум 6
    const history = (Array.isArray(body.history) ? body.history : [])
      .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .slice(-6)
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
    while (history.length && history[0].role !== 'user') history.shift();
    while (history.length && history[history.length - 1].role === 'user') history.pop();

    try {
      let answer;
      if (env.ANTHROPIC_API_KEY) answer = await askClaude(env, question, lang, history);
      else if (env.GEMINI_API_KEY) answer = await askGemini(env, question, lang, history);
      else return json({ error: 'no api key configured' }, 500);
      return json({ answer });
    } catch (e) {
      return json({ error: String(e.message || e).slice(0, 300) }, 502);
    }
  },
};
