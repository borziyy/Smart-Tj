# Smart TJ — приложение для подготовки к олимпиадам

Автор: **AKHUNOV BOZORBOY**
iOS + Android (один код на React Native / Expo).

## Что внутри

- 554 вопроса: математика, физика, химия, биология — на таджикском и русском
- Заставка с именем автора, главная, тесты, материалы (теория и формулы), профиль, AI-помощник
- Олимпиадный режим (30 вопросов, 20 минут), случайный тест, работа над ошибками
- Пояснение к каждому ответу, разбор теста, статистика, рекорды, серия дней
- Работает без интернета. AI-помощник онлайн отвечает через ИИ, офлайн — решает уравнения, считает примеры и ищет ответ по базе

## 1. Запуск на своём телефоне (15 минут)

1. Установите **Node.js LTS** с сайта nodejs.org (на Windows или Mac).
2. Распакуйте архив, откройте папку `smart-tj` в терминале (cmd / PowerShell / Terminal).
3. Выполните по очереди:
   ```
   npm install
   npx expo install --fix
   npx expo start
   ```
4. Установите на телефон приложение **Expo Go** (App Store / Google Play).
5. Отсканируйте QR-код из терминала: на Android — в Expo Go, на iPhone — камерой.

Телефон и компьютер должны быть в одной Wi-Fi сети. Если не подключается — `npx expo start --tunnel`.

Если Expo Go пишет, что версия SDK устарела, обновите проект:
```
npx expo install expo@latest
npx expo install --fix
```

## 2. Подключить онлайн-ИИ (необязательно, бесплатно)

Ключ ИИ нельзя хранить в самом приложении — его украдут. Поэтому есть маленький сервер в папке `server/`.

1. Получите ключ: бесплатно — Google Gemini на aistudio.google.com, или платно — Claude на console.anthropic.com.
2. Зарегистрируйтесь на **dash.cloudflare.com** (бесплатно) → Workers & Pages → Create → Worker.
3. Вставьте код из `server/worker.js` → Deploy.
4. В настройках Worker → Variables → добавьте секрет `GEMINI_API_KEY` (или `ANTHROPIC_API_KEY`) с вашим ключом.
5. Скопируйте адрес Worker (вида `https://smart-tj-ai.имя.workers.dev`) и вставьте его в файл `src/config.js` в `AI_PROXY_URL`.

Готово: в AI-помощнике появится зелёный значок «Онлайн». Без интернета он сам переключится в офлайн.

## 3. Публикация в Google Play и App Store

Нужны аккаунты разработчика:
- **Google Play Console** — разовый платёж $25 (play.google.com/console)
- **Apple Developer Program** — $99 в год (developer.apple.com). Mac не нужен: сборка идёт в облаке Expo.

Сборка:
```
npm install -g eas-cli
eas login              # бесплатный аккаунт на expo.dev
eas build:configure
eas build -p android --profile production   # файл .aab для Google Play
eas build -p ios --profile production       # сборка для App Store
```
Отправка в магазины:
```
eas submit -p android
eas submit -p ios
```

Для проверки на Android без магазина: `eas build -p android --profile preview` даст файл **.apk**, его можно установить на любой телефон.

**Перед публикацией:**
- В `app.json` поменяйте `bundleIdentifier` / `package` (`tj.smart.education`), если он занят.
- Опубликуйте `PRIVACY.md` как страницу (например, через GitHub Pages или Google Sites) и укажите ссылку в магазинах — без неё не примут.
- Тексты для страниц магазинов — в `STORE_LISTING.md`. Скриншоты сделайте в эмуляторе или на телефоне.
- При каждом обновлении увеличивайте `version`, `ios.buildNumber` и `android.versionCode` в `app.json`.

## Как добавить свои вопросы

Файлы `src/data/math.js`, `physics.js`, `chemistry.js`, `biology.js`. Формат одного вопроса:
```js
['Вопрос RU', ['правильный', 'неверный', 'неверный', 'неверный'], 'Пояснение RU',
 'Савол TJ', ['дуруст', 'хато', 'хато', 'хато'], 'Шарҳ TJ'],
```
Правильный ответ всегда пишется первым — в приложении варианты перемешиваются.
Остальные задачи создаёт `src/data/generators.js` (ответы вычисляются программой).

## Структура

```
app/            экраны (expo-router)
  index.js      заставка
  (tabs)/       Асосӣ, Тестҳо, Маводҳо, Профил, AI
  subject.js    выбор режима теста
  quiz.js       тест
  result.js     результат и разбор
src/            логика, тема, переводы, база вопросов, AI
server/         сервер онлайн-ИИ (Cloudflare Worker)
assets/         иконка и заставка
```
